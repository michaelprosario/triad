import { GameNode } from '../src/playtime.core/entities/game-node'

export class Thing extends GameNode
{
    start() {
        throw new Error('Method not implemented.');
    }
    
    update() {
        throw new Error('Method not implemented.');
    }

}
export enum MessageTypes{
    KeyDown = 1,
    KeyUp = 2
}
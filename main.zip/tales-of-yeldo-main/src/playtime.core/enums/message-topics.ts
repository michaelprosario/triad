export enum MessageTopics {
    UserInput = 1
}